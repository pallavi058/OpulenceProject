const mongoose = require('mongoose');


const BillSchema = new mongoose.Schema({
    title:{
         type: String,
         required:"Your Firstname is required"
     },
    userid:{
         type:String,
         required:"Your Lastname is required"
     },

    amount:{
        type:Number,
        required:"Amount is required"
     }

} ,  {
    timestamps:true
     }
);

module.exports = mongoose.model("Bill", BillSchema);

