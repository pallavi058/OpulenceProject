const mongoose = require('mongoose');


const UserSchema = new mongoose.Schema({
    firstname:{
         type: String,
         required:"Your Firstname is required"
     },
    lastname:{
         type:String,
         required:"Your Lastname is required"
     },

    email:{
        type : String,
  
        required:"Unique email is  required"
     },
     password:{
        type:String,
        required:"Password is required"
     },
    
    mobileno:{
        type:Number,
        required: "Mobile no is required"
     },
    amount:{
        type:Number,
        required:"Amount is required"
     }

} ,  {
    timestamps:true
     }
);

module.exports = mongoose.model("User", UserSchema);


