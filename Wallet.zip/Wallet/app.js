const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const User = require('./model/User');
const Bill = require('./model/Bill');
var path = require('path');
const { check, validationResult } = require('express-validator/check'); 
const validator = require('express-validator') 



app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.resolve(__dirname, 'Public')));

require('dotenv').config();
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Welcome to second project');
});

app.post('/SignUp',[
	check('email').isEmail()
    .withMessage('That email doesn‘t look right'),
  /*  .isUsernameAvailable()
  .withMessage('Email is already exist')*/
    check('password').isLength({ min: 5 })
    .withMessage('must be at least 5 chars long')
    .isLength({ max: 10}).withMessage('must be less than 10 chars')
    .matches(/\d/).withMessage('must contain a number'),
    check('mobileno')
    .isLength({ min:10})
    .withMessage('Mobile no must not be less than 10 digit number')
    .isLength({ max :10})
    .withMessage('Mobile no must not be more than 10 digit number')],(req, res) =>{
    	 const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

	console.log(req.body);
	const userData = new User(req.body).save();
	res.send(req.body);

});

app.get('/Show',async (req, res) => {
 const user = await User.find({});
    res.send(user);
});

app.post('/Bill',(req, res) =>{
	console.log(req.body);
	const billData = new Bill(req.body).save();
	res.send(req.body);
});

app.get('/ShowBill',async (req, res) => {
 const bill = await Bill.find({});
    res.send(bill);
});


app.put('/update/:userId',async(req,res) => {
	try{
		const ido = await User.findByIdAndUpdate({
			_id: req.params.userId
		}, req.body, {
			new : true,
			//runValidators:true
		
		});

		res.send(ido);

	}catch(error){

		// res.send(500);
	}
});

mongoose.connect(process.env.MONGOD_URL,{useNewUrlParser: true}).then(() => console.log('mongodb is connected'));
mongoose.Promise = global.Promise;


app.listen(process.env.PORT, () => {
console.log('Server running on port'+process.env.PORT);
});


//check('email', 'Your email is not valid').not().isEmpty().isEmail().normalizeEmail()