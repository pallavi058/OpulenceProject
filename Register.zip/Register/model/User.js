const mongoose = require('mongoose');

var uniqueValidator = require('mongoose-unique-validator');


const UserSchema = new mongoose.Schema({
    firstname:{
         type: String,
         required:"Your Firstname is required"
     },
    lastname:{
         type:String,
         required:"Your Lastname is required"
     },
	age:{
         type: Number,
         maxlength:99,
         required: "Age is required"
     },
    email:{
        type : String,
         lowercase: true,
         unique: true,
        required:"Unique email is  required"
     },
     password:{
        type:String,
        minlength:5,
        maxlength:9,
        required:"Password is required"
     },
    address:{
         type: String,
         required: "Address is required"
     },
    street:{
        type: String,
        required:"Street name is required" 
     },
    roadno:{
        type:String,
        required:"Road no is required"
     },
    city:{
        type:String,
        required: "City name is required"
     },
    state:{
        type:String,
        required: "State is required"
     },
    country:{
        type:String,
        required: "Country name is required"
     },

    landlineno:{
        type:Number,
        min:1000000000,
        max:9999999999,
     },
    mobileno:{
        type:Number,
        min:1000000000,
        max:9999999999,
        required: "Mobile no is required"
     },
    companyname:{
        type:String,
        required: "Company name is required"
     },
    companyaddress:{
        type: String,
        required: "Company address is required"
     },
    profilephoto:{
        type:String,
        required:"Profile photo is required"
     },
    companylogo:{
        type:String,
        required:"Company logo is required"
     }

} ,  {
    timestamps:true
     }
);


UserSchema.plugin(uniqueValidator);

module.exports = mongoose.model("User", UserSchema);


