const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const User = require('./model/User');


require('dotenv').config();
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Welcome to first project');
});

app.post('/SignUp',(req, res) =>{
	console.log(req.body);
	const userData = new User(req.body).save();
	res.send(req.body);
});

app.get('/Show',async (req, res) => {
 const user = await User.find({});
    res.send(user);
});


app.put('/update/:userId',async(req,res) => {
	try{
		const ido = await User.findByIdAndUpdate({
			_id: req.params.userId
		}, req.body, {
			new : true,
			//runValidators:true
		
		});

		res.send(ido);

	}catch(error){

		// res.send(500);
	}
});

app.delete('/delete/:id', async(req, res) =>{
	try{
		const idn = await User.findByIdAndRemove({
			_id: req.params.id
		});
		res.send(idn);

	}catch(error){

	}
});



app.post('/login',async(req,res)=>{
	const email = req.body.email;
	const password = req.body.password;
	const user = await User.findOne({"email": email});
	if(user){

		const post = await User.findOne({"password": password});
		if(post){

			console.log("Successful login");
			res.send("Login Successful");

		}else{
			console.log("Incorrect Password");
			res.send("Incorrect Password");
		}

	}else{
		console.log("Incorrect Email");
		res.send("Incorrect Email");
	}
});



mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);

mongoose.connect(process.env.MONGOD_URL,{useNewUrlParser: true}).then(() => console.log('mongodb is connected'));
mongoose.Promise = global.Promise;


app.listen(process.env.PORT, () => {
console.log('Server running on port'+process.env.PORT);
});