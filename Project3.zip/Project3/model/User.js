const mongoose = require('mongoose');


const UserSchema = new mongoose.Schema({
    fullname:{
         type: String,
         required:"Your Full name is required"
     },

    email:{
        type : String,
       required:"Unique email is  required"
     },

     password:{
        type:String,
        minlength:5,
        maxlength:9,
        required:"Password is required"
     },

     dob:{
     	type: String
     //	required:"Date of birth must be provided"
     },

    country:{
        type:String,
        required:"Country name is required"
     },
     gender:{
     	type: String,
     	required: "Gender must be provided"
     }

} ,  {
    timestamps:true
     }
);


module.exports = mongoose.model("User", UserSchema);





















