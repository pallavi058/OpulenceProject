const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const User = require('./model/User');
var path = require('path');
const { check, validationResult } = require('express-validator/check'); 
const validator = require('express-validator') 
const _ = require("lodash");




app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.resolve(__dirname, 'Public')));


require('dotenv').config();
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Welcome to login project');
});

app.post('/SignUp',[
	check('email').custom(async (value, { req }) => {
    let user = await User.findOne({ email: value });

    if (!_.isEmpty(user)) {
      return false;
    }
  })
  .withMessage("Email already exists")/*.custom(email => {
    if (alreadyHaveEmail(email)) {
      throw new Error('Email already registered')
    }
  })*/.isEmail()
    .withMessage('That email doesn‘t look right'),
  /*  .isUsernameAvailable()
  .withMessage('Email is already exist')*/
    check('password').isLength({ min: 5 })
    .withMessage('must be at least 5 chars long')
    .isLength({ max: 10}).withMessage('must be less than 10 chars')
    .matches(/\d/).withMessage('must contain a number')
   ],(req, res) =>{

    	const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
	console.log(req.body);
	const userData = new User(req.body).save();
	res.send(req.body);
	//res.redirect('/Public/login.html');
	//next;

});

app.get('/Show',async (req, res) => {
 const user = await User.find({});
    res.send(user);
});

app.post('/login',async(req,res)=>{
	const email = req.body.email;
	const password = req.body.password;
	const user = await User.findOne({"email": email});
	if(user){

		const post = await User.findOne({"password": password});
		if(post){

			console.log("Successful login");
			res.send("Login Successful");

		}else{
			console.log("Incorrect Password");
		    res.send("Incorrect Password");
		}

	}else{
		console.log("Incorrect Email");
		res.send("Incorrect Email");
	}
});



mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);

mongoose.connect(process.env.MONGOD_URL,{useNewUrlParser: true}).then(() => console.log('mongodb is connected'));
mongoose.Promise = global.Promise;


app.listen(process.env.PORT, () => {
console.log('Server running on port'+process.env.PORT);
});