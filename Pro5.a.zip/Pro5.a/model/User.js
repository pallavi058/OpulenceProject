const mongoose = require('mongoose');


const UserSchema = new mongoose.Schema({
    name:{
         type: String,
         required:"Your Full name is required"
     },

    email:{
        type : String,
       required:"Unique email is  required"
     },

     password:{
        type:String,
        required:"Password is required"
    },
     confirm:{
        type:String,
        required:"Confirm Password is required"
    },
    mobile:{
        type:String,
        required:"Mobile no is required"
    },
    company:{
        type:String,
        required:"Company name is required"
    }

  } ,  {
    timestamps:true
     }
);


module.exports = mongoose.model("User", UserSchema);
