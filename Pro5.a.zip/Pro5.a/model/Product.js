const mongoose = require('mongoose');


const ProductSchema = new mongoose.Schema({
    prodname:{
         type: String,
         required:"Product name is required"
     },

    hsn:{
        type : String,
       required:"HSN is  required"
     },

    pcode1:{
        type:String,
        required:"Product code1 is required"
    },
    pcode2:{
        type:String,
        required:"Product code2 Password is required"
    },
    category:{
        type:String,
        required:"Product category is required"
    },

    price:{
        type:String,
        required:"Price is required"
    },
    quantity:{
        type:Number,
        required:"Quantity is required"
    },
    description:{
        type:String,
        required:"Description of product is required"
    }

  } ,  {
    timestamps:true
     }
);


module.exports = mongoose.model("Product", ProductSchema);