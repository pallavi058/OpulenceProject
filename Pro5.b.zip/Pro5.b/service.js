const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('mongoose');
const User = require('./model/User');
const Product = require('./model/Product');
const route = require('./Routes/UserRouter');
const route1 = require('./Routes/ProductRouter');
const { check, validationResult } = require('express-validator');
/*var flash    = require('connect-flash');*/
var path = require('path'),
    fs = require('fs');

app.use(bodyParser.urlencoded({ extended: false }));

require('dotenv').config();
app.use(bodyParser.json());

app.use('/',route);
app.use('/',route1);

/*app.use(express.bodyParser()); */
app.use(express.static(path.join(__dirname, 'Public')));
app.set('views', [__dirname + '/views']);
app.engine('html', require('ejs').renderFile);
/*app.use(flash()); 
*/ 
mongoose.connect(process.env.MONGOD_URL,{useNewUrlParser: true}).then(() => console.log('mongodb is connected'));


mongoose.Promise = global.Promise;

app.listen(process.env.PORT, () => {
    console.log('Server works on port ' +process.env.PORT);
});

/*
Multiple View paths on Node.js + Express

app.set('views', [__dirname + '/viewsFolder1', __dirname + '/viewsFolder2']);*/