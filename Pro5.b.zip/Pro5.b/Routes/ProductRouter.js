const router = require("express").Router();
const mongoose = require("mongoose");
const Product = mongoose.model("Product");
var path = require('path'),
   fs = require('fs');


router.get('/addP', function(request, response) {
response.render('addProd.html');
		});

router.post('/addP',(req, res) =>{
  console.log(req.body);
	const productData = new Product(req.body).save();
	res.send(req.body);

});

router.get('/list',function(request,response){
	response.render('table.html');
});

router.get('/list',async (req, res) => {
 const products = await Product.find({});
    res.send(products);
});

/*router.get('/list',function(req,res){
	const products = await Product.find({});
	products.forEach(function(doc,err){
		assert.equal(null,err);
		resultArray.push(doc);

	},function(){
		console.log(resultArray);
      res.send(resultArray);

	});
});
*/


module.exports = router;


