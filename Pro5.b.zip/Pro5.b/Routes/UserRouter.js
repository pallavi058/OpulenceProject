const router = require("express").Router();
const mongoose = require("mongoose");
const User = mongoose.model("User");
/*const Product = mongoose.model("Product");*/
var path = require('path'),
   fs = require('fs');
const { check, validationResult } = require('express-validator');



router.get('/SignUp', function(request, response) {
response.render('signup.html'/*, { message: request.flash('signuperror') }*/);
		});

router.post('/SignUp',[
  check('email').isEmail()
  .withMessage('must be in email format')
  .custom((value, {req}) => {
            return new Promise((resolve, reject) => {
              User.findOne({email:req.body.email}, function(err, user){
                if(err) {
                  reject(new Error('Server Error'))
                }
                if(Boolean(user)) {
                  reject(new Error('E-mail already in use'))
                }
                resolve(true)
              });
            });
          }),
  check('password').isLength({ min: 5 })
  .withMessage('must be at least 5 chars long')
  .not()
  .isEmpty()
  .withMessage('Password is required')
  .isLength({ max: 10})
  .withMessage('must be less than 10 chars')
  .matches(/\d/).withMessage('must contain a number'),
           // Check Password Confirmation
  check('confirm', 'Passwords do not match')
  .exists()
  .custom((value, { req }) => value === req.body.password),
  check('name')
  .isAlpha()
  .withMessage('Must be only alphabetical chars')
  .isLength({ min: 5 })
  .withMessage('Must be at least 5 chars long')
],(req, res) =>{

	const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
	console.log(req.body);
	const userData = new User(req.body).save();
	res.send(req.body);

});

router.get('/Show',async (req, res) => {
 const user = await User.find({});
    res.send(user);
});


router.get('/login', function(request, response) {
response.render('login.html');
		});


router.post('/login',async(req,res)=>{
	const email = req.body.email;
	const password = req.body.password;
	const user = await User.findOne({"email": email});
	if(user){

		const post = await User.findOne({"password": password});
		if(post){

			console.log("Successful login");
      // res.redirect('../views/dashboard');
			/*res.send("Login Successful");*/
    // res.sendFile(path.join(__dirname, '../views/dashboard.html'));
   res.sendFile(path.join(__dirname, '../views/index.html'));
		}else{
			console.log("Incorrect Password");
		    res.send("Incorrect Password");

		}

	 }else{
		console.log("Incorrect Email");
		res.send("Incorrect Email");

	}
});

router.get('/dashboard', function(req, res) {
  //res.render('dashboard.html');
  res.render('index.html');
});


/*router.get('/addP', function(request, response) {
response.render('add.html');
    });

router.post('/addP',(req, res) =>{
  console.log(req.body);
  const productData = new Product(req.body).save();
  res.send(req.body);

});

router.get('/ShowP',async (req, res) => {
 const product = await Product.find({});
    res.send(product);
});
*/
module.exports = router;
