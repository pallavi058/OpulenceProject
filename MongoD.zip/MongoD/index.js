/*//Database created
var MongoClient = require('mongodb').MongoClient;
//Create a database named "mydb":
var url = "mongodb://localhost:27017/mydb2";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  console.log("Database created!");
  db.close();
});*/


//Collection created


/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Create a collection name "customers":
  dbo.createCollection("tutorial", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");
    db.close();
  });
});
*/

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  var myobj = [
    {  _id: "7df78ad8932c",  title: 'MongoDB Overview', description: 'MongoDB is no sql database', by_user: 'wisdomjobs', url: 'http://www.wisdomjobs.com', tags: ['mongodb', 'database', 'NoSQL'], likes: 100},
    {  _id: '7df78ad8942d',  title: 'NoSQL Overview', description: 'No sql database is very fast', by_user: 'wisdomjobs',url: 'http://www.wisdomjobs.com', tags: ['mongodb', 'database', 'NoSQL'], likes: 10},
    {  _id: '7df78ad8952f',  title: 'MySQL Overview', description:'MySQL is database',by_user: 'tutorialspoint',url:'http://www.tutorialspoint.com',tags:['nodejs', 'database','MySQL'],likes:200},
    {  _id: '7df78ad8962g',  title: 'Java Overview', description:'Java is a programming language',by_user: 'quicklearner',url:'http://www.quicklearner.com',tags:['java', 'c++','python'],likes:230},
    {  _id: '7df78ad8972h',  title: 'Python Overview', description:'Python is used for multiple things',by_user: 'tutorialspoint',url:'http://www.tutorialspoint.com',tags:['machineLearning', 'java','html'],likes:300},
    { _id: '7df78ad8908e', title: 'Neo4j Overview', description: 'Neo4j is no sql database', by_user: 'Neo4j', url: 'http://www.neo4j.com', tags: ['neo4j', 'database', 'NoSQL'], likes: 750}
      ];
  dbo.collection("tutorial").insertMany(myobj, function(err, res) {
    if (err) throw err;
    console.log("Number of documents inserted: " + res.insertedCount);
    db.close();
  });
});*/


/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Insert 3 documents, with specified id values:
  var myobj = [
    { _id: 154, name: 'Chocolate Heaven'},
    { _id: 155, name: 'Tasty Lemon'},
    { _id: 156, name: 'Vanilla Dream'}
  ];
  dbo.collection("products").insertMany(myobj, function(err, res) {
    if (err) throw err;
    //Return the result object:
    console.log(res);
    db.close();
  });
});*/


//Find all documents in the customers collection:

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Find all documents in the customers collection:
  dbo.collection("tutorial").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});

*/


//Find the first document in the customers collection:

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Find the first document in the customers collection:
  dbo.collection("tutorial").findOne({}, function(err, result) {
    if (err) throw err;
    console.log(result.name);
    db.close();
  });
});
*/


//Find all documents in the customers collection:
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Find all documents in the customers collection:
  dbo.collection("tutorial").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});*/



//Return the fields "name" and "address" of all documents in the customers collection:
//FindSome 

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Exclude the _id field from the result:
  dbo.collection("tutorial").find({}, { projection: { _id: 0, title: 1, url: 1 } }).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});

*/

//This example will exclude "address" from the result:

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  //Exclude "address" field in the result:
  dbo.collection("customers").find({}, { projection: { address: 0 } }).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});
*/
 
 //This code will display only name field 

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

MongoClient.connect(url,  { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
    var dbo = db.db("mydb");
  //Return only the "name" field in the result:
  dbo.collection("customers").find({}, { projection: { _id: 0, name: 1 } }).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});*/

//Filter the Result
// Find documents with the address "Valley 345":

/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Return only the documents with the address "Valley 345":
  var query = { title:"Python Overview" };
  dbo.collection("tutorial").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});
*/

//Filter With Regular Expressions
// Find documents where the address starts with the letter "S":
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
 // Return only the documents where the address starts with an "V":
  var query = { title: /^M/ };
  dbo.collection("tutorial").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});*/


//Sort the Result
// Sort the result alphabetically by name:
/*


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Sort the result by name:
  var sort = { title: 1 };
  dbo.collection("tutorial").find().sort(sort).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});

*/
//Sort the result reverse alphabetically by name:
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Sort the result descending by name:
  var sort = { title: -1 };
  dbo.collection("tutorial").find().sort(sort).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});*/


// Delete the document with the address "Valley 345 ":
/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  Delete the first customers with the address "Mountain 21":
  var myquery = { address: 'Valley 345' };
  dbo.collection("customers").deleteOne(myquery, function(err, obj) {
    if (err) throw err;
    console.log("1 document deleted");
    db.close();
  });
});
*/

//Delete Many

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  //Delete all customers where the address starts with an "H":
  var myquery = { address: /^H/ };
  dbo.collection("customers").deleteMany(myquery, function(err, obj) {
    if (err) throw err;
    console.log(obj.result.n + " document(s) deleted");
    db.close();
  });
});*/


// Delete the "customers" table:

/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  //Delete the "customers" collection:
  dbo.collection("customers").drop(function(err, delOK) {
    if (err) throw err;
    if (delOK) console.log("Collection deleted");
    db.close();
  });
});
*/


// Delete the "customers" collection, using dropCollection():


/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  //Delete the "customers" collection:
  dbo.dropCollection("customers", function(err, delOK) {
    if (err) throw err;
    if (delOK) console.log("Collection deleted");
    db.close();
  });
});

*/


//Update the document with the address "Valley 345" to name="Mickey" and address="Canyon 123":




/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  var myquery = { by_user: "Neo4j" };
  var newvalues = { $set: { by_user: "neo4j", likes: "123" } };
  dbo.collection("tutorial").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});
*/

//Update the address from "Valley 345" to "Canyon 123":

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var myquery = { address: "Lowstreet4" };
  var newvalues = {$set: {address: "Canyon"} };
  dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});
*/

//Update all documents where the name starts with the letter "P":

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var myquery = { address: /^P/ };
  var newvalues = {$set: {name: "Minnie"} };
  dbo.collection("customers").updateMany(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log(res.result.nModified + " document(s) updated");
    db.close();
  });
});
*/

//Limit the result to only return 5 documents:


/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,{ useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
  //Return the first 5 customers:
  dbo.collection("tutorial").find().limit(2).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});*/



//MongoDB is not a relational database, but you can perform a left outer join by using the $lookup stage.
// Join the matching "products" document(s) to the "orders" collection:

/*
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";


MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
 dbo.collection('tutorial').aggregate([
 	{ $lookup:
       {
         from: 'products',
         localField: 'product_id',
         foreignField: '_id',
         as: 'orderdetails'
       }
     }*/

/*var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";


MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
db.products.aggregate([
   {
     $lookup:
       {
         from: "tutorial",
         localField: "name",
         foreignField: "by_user",
         as: "tutorial_docs"
       }
  }
]).toArray(function(err, res) {
    if (err) throw err;
    console.log(JSON.stringify(res));
    db.close();
  });
});
*/

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://127.0.0.1:27017/";

MongoClient.connect(url, { useNewUrlParser: true },function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb2");
 // dbo.collection('products').aggregate([
	 dbo.collection('tutorial').aggregate([
    /*{ $lookup:
      {
        from: 'tutorial',
        localField: 'name',
        foreignField: 'by_user',
        as: 'tutorial_docs'
      }
    },*/
   //{ $match: { title : "Python Overview"} },  //match is not working
    //{ $match: { _id : 155 } },
   { $sort: { title: 1, by_user: 1 } },
   { $group : { _id : "$by_user" , totalLikes: { $sum : "$likes"}/*minLikes : { $min : "$likes"}*//*, firstS: { $first: "$likes" },avgLikes : { $avg: "$likes"}*/ } } 
   // { $group: { _id: null, count: { $sum: 1 } } }
  ]).toArray(function(err, res) {
    if (err) throw err;
    console.log(JSON.stringify(res));
    db.close();
  });
});

//The $where can not be used in $match queries as part of the aggregation pipeline.

/*
$group:
         {
           _id: "$item",
           minQuantity: { $min: "$quantity" }
         }
*/