const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

const UserSchema = new mongoose.Schema({
    Name:{
        type: String,
        required:"Your name is required"
     },
    email:{
         type:String,
         lowercase: true,
         unique: true,
         required: "EmailId is required"
     },
	password:{
         type: String,
         minlength:6,
         maxlength:7,
         required: "Password is required"
     },
    MobileNo:{
     	type : Number,
     	//pattern: "^[0][1-9]\d{9}$|^[1-9]\d{9}$",
     	min:1000000000,
     	max:9999999999,
        required:"Mobile number is required"
     }

} , {
    timestamps:true
    }
);


UserSchema.plugin(uniqueValidator);


module.exports = mongoose.model("User", UserSchema)

